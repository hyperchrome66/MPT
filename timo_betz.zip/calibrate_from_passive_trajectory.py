# -*- coding: utf-8 -*-
"""
Created on Wed Dec 15 15:11:31 2021

@author: tmuenker

Get Calibration data from passive trajecktories

Get kappa,gamma,eta,D_fluid,Theoretical PSD
"""

import numpy as np
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
import os
import pickle


#%%
'''Import trajectories'''
root = tk.Tk()
root.withdraw()

main_path = filedialog.askdirectory(title='Choose calibration file')
os.chdir(main_path)

with open(main_path+r'/traject.dat', 'rb') as f:
    data = pickle.load(f)    


time=data['Time']


'''Create array of Trjactories'''
#We will have 100 trajectories
#Each is a measurement of 1s with a rate of 65536 Hz
rate=65536
dt=1/rate
N=len(time)

traject = list(data.values())
traject = np.array(traject)
traject = traject [:-1]

#%%%
'''Calculate MSD'''
def getMSD(time,x,sampling_rate,maxtime=.5,increment=3):
    
    lag=np.linspace(0,int(maxtime*sampling_rate),int(maxtime*sampling_rate+1))
    lag=lag[::3]
    
    msd=[]
    for n in lag:
       n=int(n)

       if n==0:
           diff_sq=0
       else:
           diff = x[n:]-x[:-(n)] #this calculates r(t + dt) - r(t)
           diff_sq = diff**2
       MSD = np.mean(diff_sq)
       msd.append(MSD)
        
        
    
    return(lag/sampling_rate,msd)



MSD=[]
for x in traject:

    lagtimes,msd=getMSD(time,x,rate)
    MSD.append(msd)

MSD=np.asarray(MSD)

plt.figure()
plt.title('MSD')
plt.loglog(lagtimes,np.mean(MSD,0),'.-')


#%%
meanMSD=np.mean(MSD,0)
timeMSD=lagtimes

#%%
'''Get mean variance'''
variance=[]
for x in traject:
    variance.append(np.var(x))
    
variance=np.mean(variance)

T=293.15
kb=1.38*10**(-23)
R=0.5*10**(-6)

all_kappa=kb*T/np.asarray(variance)/10**(-12) #N/m
kappa=np.mean(all_kappa)
kappa_error=np.std(all_kappa)

'''Get gamma from MSD'''
idex=np.argmin(np.abs(np.asarray(meanMSD)-1.5e-5))
if idex==0:idex=2
gamma0=2*kb*T*timeMSD[idex]/meanMSD[idex]*10**12

plt.figure()
plt.loglog(timeMSD,meanMSD)
plt.plot([0,timeMSD[idex]],[0,meanMSD[idex]],'--')
D_calculated=kb*T/gamma0

#viscosity=kappa/(12*R*np.pi**2*fit[1][1]) #Pa*s

viscosity=kb*T/D_calculated/(6*np.pi*R)
#%%
'''Get PSD'''
def generatePSD(N,rate,data):
    #Generates the PSD for N samples measured with the frequency rate
    xdft=np.fft.fft(data)
    xdft=np.abs(xdft*np.conjugate(xdft))
    xdft=xdft/(N*rate)
    xdft.resize(int(N/2))
    return(xdft)

psd=[]
for x in traject:
    psd.append(generatePSD(N,rate,x))
    
    
meanPSD=np.mean(psd,0)
psd_freq=np.fft.fftfreq(N, d=1/rate)
psd_freq.resize(int(N/2))

plt.figure('PSD')
plt.loglog(psd_freq,meanPSD,label='From Data')



'''Calculate theoretical PSD'''
fc=kappa/(2*np.pi*gamma0)
psd_theoretical=D_calculated/(2*np.pi**2*(psd_freq**2+fc**2))
plt.loglog(psd_freq,psd_theoretical*10**12,label='From theory')

plt.legend()
plt.show()



plt.figure()
plt.loglog(psd_freq,meanPSD/(psd_theoretical*10**12))

#%%
'''Results'''
results={}
results['kappa']=kappa
results['kappa error']=kappa_error
results['gamma']=gamma0
results['D fluid']=D_calculated
results['MSD']=timeMSD,meanMSD
results['PSD theoretical']=psd_freq,psd_theoretical*10**12

with open(main_path+r'\calibration.dat', 'wb') as f:
    pickle.dump(results, f)







