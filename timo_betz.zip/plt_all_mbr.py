# -*- coding: utf-8 -*-
"""
Created on Wed Jun  7 14:27:25 2023

@author: tmuenker
"""
import numpy as np
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
import os
import pickle
from decimal import Decimal
from scipy.optimize import curve_fit
from scipy import interpolate
from scipy import stats
from matplotlib.lines import Line2D


'''Import Data'''
root = tk.Tk()
root.withdraw()

main_path = filedialog.askdirectory(title='Choose Main folder')
os.chdir(main_path)


folders=[d for d in os.listdir(os.getcwd()) if os.path.isdir(d)]

All_Results={}

for folder in folders:
    All_Results[folder]=np.load(main_path+r'/'+folder+r'/Analysis.dat',allow_pickle=True)
    print('Loading '+folder)
print('Loading done')
#%%

#Now plot all results

for folder in folders:
    res=All_Results[folder]
    plt.figure('MBR')
    plt.errorbar(res['All MCD'][0],np.mean(np.array(res['All MCD'][1]),0),stats.sem(np.array(res['All MCD'][1]),0),label=folder)
    plt.xlabel('Time [s]')
    plt.ylabel('MBR')
    plt.legend()
    plt.tight_layout()
    
plt.savefig(main_path+r'\all_mbr.png')
plt.savefig(main_path+r'\all_mbr.pdf')
    
plt.show()

for folder in folders:
    res=All_Results[folder]
    plt.figure('MSD')
    plt.loglog()
    plt.errorbar(res['All MSD'][0][1:],np.mean(np.array(res['All MSD'][1]),0)[1:],stats.sem(np.array(res['All MSD'][1]),0)[1:],label=folder)
    plt.xlabel('Time [s]')
    plt.ylabel('MSD')
    plt.legend()
    plt.tight_layout()
plt.plot(res['All MSD'][0][1:],res['All MSD'][0][1:]*10**-1.8,'k--',label='Normal dissusion')

plt.savefig(main_path+r'\all_msd.png')
plt.savefig(main_path+r'\all_msd.pdf')
    
plt.show()