# -*- coding: utf-8 -*-
"""
Created on Mon Dec 20 18:33:52 2021

@author: tmuenker


Plot figures for drugged cells

"""

import matplotlib.pyplot as plt
import numpy as np
import os
from textwrap import wrap
import tkinter as tk
from tkinter import filedialog
import pickle
from scipy.optimize import curve_fit,minimize
plt.style.use('default')

plt.rcParams['figure.figsize'] = 5,4


#%%
#Fildedialog box
root = tk.Tk()
root.withdraw() 

main_path= filedialog.askdirectory(title='Select Experiment folder')
fig_path=main_path
#%%
'''Start showing response and G for HeLa cell'''


data=np.load(main_path+"/HeLa/all_results.pkl",allow_pickle=True)

medians=data['medians']

tau='0p0006'
kb=1.38064852*10**(-23) #J/K
T=310   #K

#%%
'''Plot Response functions'''
freq=medians['freq']
res_imag=medians['Res imag median']
psd=medians['psd median']

plt.figure('Response')
plt.title('Response')
plt.loglog()
# plt.loglog(freq,psd[0]*np.pi*freq/(kb*T) *(10**-18),'bo-',label=r'$C(f) \frac{\pi f}{k_B T}$')
# plt.loglog(freq,res_imag[0],'ro-',label=r'$X^{\prime\prime}(f)$')
plt.errorbar(freq,psd[0]*np.pi*freq/(kb*T) *(10**-18),psd[1]*np.pi*freq/(kb*T) *(10**-18),linestyle='--',marker='o',capsize=5,color='k',label=r'$C(f) \frac{\pi f}{k_B T}$')
plt.errorbar(freq,res_imag[0],res_imag[1],linestyle='-',marker='.',capsize=5,color='black',label=r'$X^{\prime\prime}(f)$')
plt.fill_between(freq, res_imag[0], psd[0]*np.pi*freq/(kb*T) *(10**-18),color='red',alpha=0.2)

#
Response_apparent_data=psd[0]*np.pi*freq/(kb*T) *(10**-18)
Response_apparent_error=psd[1]*np.pi*freq/(kb*T) *(10**-18)

Response_data=res_imag[0]
Response_error=res_imag[1]

plt.show()
plt.xlabel(r'Frequency [Hz]')
plt.ylabel(r'Response [m/N]')
plt.legend()
plt.tight_layout()



# filename='Response WT'+tau
# plt.savefig(fig_path+'/'+filename+'.png',format='png',bbox_inches='tight')
# plt.savefig(fig_path+'/'+filename+'.pdf',format='pdf',bbox_inches='tight')  


#%%
'''Plot complex modulus with Fit'''
G_real=medians['G real median']
G_imag=medians['G imag median']

def fitGKVmodel_curve_fit(param,freq,G_real,G_imag):
    omega=np.pi*2*freq
    ca=param[0]
    a=param[1]
    cb=param[2]
    b=param[3]
    def diffGKV(freq,ca,a,cb,b):
        omega=np.pi*2*freq
        G_model_re=ca*omega**a*np.cos(a*np.pi/2)+cb*omega**b*np.cos(b*np.pi/2)
        G_model_im=ca*omega**a*np.sin(a*np.pi/2)+cb*omega**b*np.sin(b*np.pi/2)
        return np.append(np.log(G_model_re),np.log(G_model_im))    
    popt,pcov=curve_fit(diffGKV,freq,np.append(np.log(G_real),np.log(G_imag)),p0=param,maxfev=100000)
    return(popt)

def plotGKV(param,freq):
    omega=np.pi*2*freq
    ca=param[0]
    a=param[1]
    cb=param[2]
    b=param[3]
    Greal=ca*omega**a*np.cos(a*np.pi/2)+cb*omega**b*np.cos(b*np.pi/2)
    Gimag=ca*omega**a*np.sin(a*np.pi/2)+cb*omega**b*np.sin(b*np.pi/2)
    plt.plot(freq,Greal,color='black')
    plt.plot(freq,Gimag,color='black')

p0=[12,0.37,0.21,0.8]
fit=fitGKVmodel_curve_fit(p0, freq, G_real[0], G_imag[0])


plt.figure('Complex moduli')
plt.title('Complex modulus')
plt.loglog()
plotGKV(fit, freq)
# plt.loglog(freq,G_real[0],'bo',label=r'$G^\prime(f)$')
# plt.loglog(freq,G_imag[0],'ro',label=r'$G^{\prime\prime}(f)$')
plt.errorbar(freq,G_real[0],G_real[1],linestyle='',marker='o',capsize=5,label=r'$G^\prime(f)$')
plt.errorbar(freq,G_imag[0],G_imag[1],linestyle='',marker='o',capsize=5,label=r'$G^{\prime\prime}(f)$')
plt.legend()
plt.ylim([5,500])

plt.xlabel('Frequency [Hz]')
plt.ylabel('Complex modulus [Pa]')

# plt.tight_layout()
# plt.show()
# filename='G complex fit WT'+tau
# plt.savefig(fig_path+'/'+filename+'.png',format='png',bbox_inches='tight')
# plt.savefig(fig_path+'/'+filename+'.pdf',format='pdf',bbox_inches='tight')  
#%%

'''Now show Effective energies and MSDs for HeLa and drugged'''
def fitEff(freq,eff,p0):
    fitfun =lambda freq,E0,E1: E0*freq**(E1)+1
    
    popt, pcov = curve_fit(fitfun, freq, eff,p0=p0,maxfev=5000) #,bounds=([-20,1],[20,50])
    return(popt)
fitfun =lambda freq,E0,E1: E0*freq**(-1.)+1
p0=[12,-1]
fine_freq=np.linspace(freq[0],freq[-1],1000)

#HeLa
data=np.load(main_path+"/HeLa//all_results.pkl",allow_pickle=True)
medians=data['medians']
Eff_HeLa=medians['E median']
fit_Hela=fitEff(freq,Eff_HeLa[0],p0)

#Drugged
data=np.load(main_path+"/Drugged//all_results.pkl",allow_pickle=True)
medians=data['medians']
Eff_Drugged=medians['E median']
fit_Drugged=fitEff(freq,Eff_Drugged[0],p0)

plt.figure('Effective Energies_HeLa_Drugged')
plt.title('Effective Energies')
plt.semilogx()
plt.errorbar(freq,Eff_HeLa[0],Eff_HeLa[1],linestyle='',marker='.',color='red',capsize=5)
plt.plot(fine_freq,fitfun(fine_freq,*fit_Hela),color='red',linestyle='--')
plt.errorbar(freq,Eff_Drugged[0],Eff_Drugged[1],linestyle='',marker='.',color='blue',capsize=5)
plt.plot(fine_freq,fitfun(fine_freq,*fit_Drugged),color='blue',linestyle='--')
plt.xlabel('Frequency [Hz]')
plt.ylabel(r'Effective Energy [$k_B T$]')
plt.tight_layout()
filename='Effective Energies HeLa Drugged'+tau
# plt.savefig(fig_path+'/'+filename+'.png',format='png',bbox_inches='tight')
# plt.savefig(fig_path+'/'+filename+'.pdf',format='pdf',bbox_inches='tight') 
#%%
'''Show MSDs'''

data=np.load(main_path+r'/HeLa/results_msd.pkl',allow_pickle=True)
lagtime=data[0]
MSD_HeLa=np.mean(data[1],0)
data=np.load(main_path+r'/Drugged/results_msd.pkl',allow_pickle=True)
lagtime=data[0]
MSD_Drugged=np.mean(data[1],0)
plt.rcParams['figure.figsize'] = 2.5,2
plt.figure('MSDs HeLa Drugged')
plt.title('MSDs')
#plt.xlim([1.e-4,1])
plt.loglog()
plt.plot(lagtime,MSD_HeLa,color='red')
plt.plot(lagtime,MSD_Drugged,color='blue')
plt.plot(lagtime,1.e-3* lagtime,'g--',label='Normal diffusion')
plt.legend()
plt.tight_layout()
filename='MSd HeLa Drugged'+tau
plt.savefig(fig_path+'/'+filename+'.png',format='png',bbox_inches='tight')
plt.savefig(fig_path+'/'+filename+'.pdf',format='pdf',bbox_inches='tight') 


#%%

'''Get MBR from MSD'''
plt.rcParams['figure.figsize'] = 5,4

'''heLa'''
data=np.load(main_path+r'/HeLa/results_msd.pkl',allow_pickle=True)
MSD=np.mean(data[1],0)*10**-12
lagtimes=data[0]


#crop msd at beginning 
MSD=MSD[4:]
MSDtime=lagtimes[4:]



T=310 # K
kb=1.38*10**(-23) #kg*m^2 / (s^2 *K)


index=np.argmin(np.abs(MSDtime-0.01))
#index=2

gamma0=2*kb*T*MSDtime[index]/MSD[index]

gamma0=2*kb*T/(np.gradient(MSD,MSDtime)[0])
gamma_range=gamma0*np.asarray([0.5,0.8,1,1.2,1.5])
gamma_range=gamma0*np.linspace(0.5,1.5,7)



prefactor=gamma0/(4*kb*T)
MCDbyMSD=0.5-prefactor*np.gradient(MSD,MSDtime)
MCDbyMSDfreq=MSDtime



#%%  
with open(main_path+'/HeLa/results_tau'+tau+'.pkl', 'rb') as f:
#with open(main_path+'/results_tau0p01.pkl', 'rb') as f:
    MCD_results = pickle.load(f) 
    
    #Cut it off so it covers the same lagtimes as MCD
    cutoff=MCD_results[0][-1]
    cutoff=1
    cutoff_index=np.argmin(np.abs(MCDbyMSDfreq-cutoff))
    MCDbyMSD=MCDbyMSD[:cutoff_index]
    MCDbyMSDfreq=MCDbyMSDfreq[:cutoff_index]
    
    plot_until=np.argmin(abs(MCD_results[0]-MCDbyMSDfreq[-1]))
    plt.figure('MBR')
    plt.title(r'MBR Wt and drugged')
    plt.plot(MCD_results[0][:plot_until],MCD_results[1][:plot_until],label='MBR WT',color='red')
    
    plt.xlabel('Lagtimes [s]')
    plt.ylabel('MBR')
    #plt.text(0.25, 0.32, r'$MBR=-\frac{\gamma_0}{4k_BT}\frac{d}{dt}MSD+\frac{1}{2}$')
    #plt.text(0.25, 0.3, r'$MBR=- \dfrac{\gamma_0}{4k_BT}$')
    plt.legend()    
    


    plt.tight_layout()
    plt.show()
    

    
'''Drugged'''
data=np.load(main_path+r'/Drugged/results_msd.pkl',allow_pickle=True)
MSD=np.mean(data[1],0)*10**-12
lagtimes=data[0]


#crop msd at beginning 
MSD=MSD[4:]
MSDtime=lagtimes[4:]

T=310 # K
kb=1.38*10**(-23) #kg*m^2 / (s^2 *K)



gamma0=2*kb*T*MSDtime[index]/MSD[index]
gamma0=2*kb*T/(np.gradient(MSD,MSDtime)[0])

gamma_range=gamma0*np.asarray([0.5,0.8,1,1.2,1.5])
gamma_range=gamma0*np.linspace(0.5,1.5,7)

prefactor=gamma0/(4*kb*T)

MCDbyMSD=0.5-prefactor*np.gradient(MSD,MSDtime)
MCDbyMSDfreq=MSDtime





#%%

with open(main_path+'/Drugged/results_tau'+tau+'.pkl', 'rb') as f:
#with open(main_path+'/results_tau0p01.pkl', 'rb') as f:
    MCD_results = pickle.load(f) 
    
    #Cut it off so it covers the same lagtimes as MCD
    cutoff=MCD_results[0][-1]
    cutoff=1
    cutoff_index=np.argmin(np.abs(MCDbyMSDfreq-cutoff))
    MCDbyMSD=MCDbyMSD[:cutoff_index]
    MCDbyMSDfreq=MCDbyMSDfreq[:cutoff_index]
    
    plot_until=np.argmin(abs(MCD_results[0]-MCDbyMSDfreq[-1]))
    plt.figure('MBR')
    plt.title(r'MBR Wt and drugged')
    plt.plot(MCD_results[0][:plot_until],MCD_results[1][:plot_until],label='MBR Drugged',color='blue')
    
    plt.xlabel('Lagtimes [s]')
    plt.ylabel('MBR')
    #plt.text(0.25, 0.32, r'$MBR=-\frac{\gamma_0}{4k_BT}\frac{d}{dt}MSD+\frac{1}{2}$')
    #plt.text(0.25, 0.3, r'$MBR=- \dfrac{\gamma_0}{4k_BT}$')

    plt.legend()    


    plt.tight_layout()
    plt.show()
    
filename='MBR_WT_and_drugged'+tau
plt.savefig(fig_path+'/'+filename+'.png',format='png',bbox_inches='tight')
plt.savefig(fig_path+'/'+filename+'.pdf',format='pdf',bbox_inches='tight') 







